/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  MapPin, 
  DollarSign, 
  GraduationCap, 
  Clock, 
  CheckCircle2, 
  Circle, 
  Search, 
  Filter,
  Users,
  Building2,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { UNIVERSITIES, University } from './types.ts';

// Timezone Utility
const useCurrentTime = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTIme = (date: Date, timeZone?: string) => {
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
      timeZone: timeZone || 'Asia/Seoul',
    }).format(date);
  };

  const getDayLabel = (date: Date, timeZone: string) => {
    const local = new Date(date.toLocaleString('en-US', { timeZone: 'Asia/Seoul' }));
    const target = new Date(date.toLocaleString('en-US', { timeZone }));
    if (target.getDate() < local.getDate()) return 'Yesterday';
    if (target.getDate() > local.getDate()) return 'Tomorrow';
    return 'Today';
  };

  return {
    kst: formatTIme(time),
    est: formatTIme(time, 'America/New_York'),
    cst: formatTIme(time, 'America/Chicago'),
    pst: formatTIme(time, 'America/Los_Angeles'),
    labels: {
      est: getDayLabel(time, 'America/New_York'),
      cst: getDayLabel(time, 'America/Chicago'),
      pst: getDayLabel(time, 'America/Los_Angeles'),
    }
  };
};

export default function App() {
  const times = useCurrentTime();
  const [activeTab, setActiveTab] = useState<'explorer' | 'tracker' | 'dashboard'>('explorer');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUniv, setSelectedUniv] = useState<University | null>(null);
  const [trackedSchools, setTrackedSchools] = useState<string[]>([]);

  // Load tracked schools from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('tracked_schools');
    if (saved) setTrackedSchools(JSON.parse(saved));
  }, []);

  const toggleTrack = (id: string) => {
    const next = trackedSchools.includes(id) 
      ? trackedSchools.filter(i => i !== id) 
      : [...trackedSchools, id];
    setTrackedSchools(next);
    localStorage.setItem('tracked_schools', JSON.stringify(next));
  };

  const filteredUniversities = UNIVERSITIES.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.major.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans">
      {/* Upper Navigation / Time Bar */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white">
              <TrendingUp size={24} />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">HAFS Finance Bridge</h1>
              <p className="text-xs text-slate-500 font-medium">STEM / Quant / Finance Pathways</p>
            </div>
          </div>

          <div className="flex gap-4 items-center overflow-x-auto pb-2 md:pb-0">
            <TimeDisplay label="KOREA (KST)" time={times.kst} status="Local" color="indigo" />
            <div className="w-px h-8 bg-slate-200 hidden md:block" />
            <TimeDisplay label="EST (NY/MA)" time={times.est} status={times.labels.est} />
            <TimeDisplay label="CST (IL/TX)" time={times.cst} status={times.labels.cst} />
            <TimeDisplay label="PST (CA)" time={times.pst} status={times.labels.pst} />
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Tab Switcher */}
        <div className="flex bg-slate-100 p-1 rounded-2xl w-fit mb-8 border border-slate-200">
          <TabButton 
            active={activeTab === 'explorer'} 
            onClick={() => setActiveTab('explorer')}
            label="Univ Explorer"
            icon={<Search size={18} />}
          />
          <TabButton 
            active={activeTab === 'tracker'} 
            onClick={() => setActiveTab('tracker')}
            label="Application Tracker"
            icon={<CheckCircle2 size={18} />}
          />
          <TabButton 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')}
            label="Financial Specs"
            icon={<DollarSign size={18} />}
          />
        </div>

        {activeTab === 'explorer' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="md:col-span-2 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input 
                  type="text" 
                  placeholder="대학교, 전공, 지역 검색..."
                  className="w-full bg-white border border-slate-200 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="hidden lg:flex items-center gap-2 text-sm text-slate-500 bg-indigo-50 border border-indigo-100 rounded-xl px-4 py-3">
                <AlertCircle size={16} className="text-indigo-600" />
                <span>모든 전공은 STEM(OPT 3년) 인증 과정입니다.</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredUniversities.map((univ) => (
                <UniversityCard 
                  key={univ.id}
                  univ={univ} 
                  isTracking={trackedSchools.includes(univ.id)}
                  onToggleTrack={() => toggleTrack(univ.id)}
                  onClick={() => setSelectedUniv(univ)}
                />
              ))}
            </div>
          </div>
        )}

        {activeTab === 'tracker' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <Calendar className="text-indigo-600" />
                핵심 마일스톤 관리
              </h2>
              <div className="grid gap-4">
                <TrackerItem 
                  title="CSS Profile 작성 시작" 
                  desc="재정지원 신청을 위한 필수 서류 (지원 대학별 마감일 확인 필수)"
                  date="Current"
                  status="urgent"
                />
                <TrackerItem 
                  title="Common App Supplementals" 
                  desc="각 대학별 추가 에세이 (Personal Statement 완료 후 진행)"
                  date="Nov - Jan"
                  status="ongoing"
                />
                <TrackerItem 
                  title="F1 비자 인터뷰 준비" 
                  desc="최종 합격 후 I-20 수령 단계"
                  date="Summer 2027"
                  status="upcoming"
                />
              </div>

              <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
                <h3 className="font-bold text-lg mb-4">Tracked Schools Checklist</h3>
                {trackedSchools.length === 0 ? (
                  <p className="text-slate-500 italic pb-4">탐색 탭에서 학교를 추가해주세요.</p>
                ) : (
                  <div className="space-y-4">
                    {trackedSchools.map(id => {
                      const u = UNIVERSITIES.find(u => u.id === id);
                      return u ? (
                        <div key={id} className="p-4 bg-slate-50 rounded-xl flex items-center justify-between border border-slate-100">
                          <div>
                            <span className="font-bold">{u.name}</span>
                            <div className="flex gap-4 text-xs text-slate-500 mt-1">
                              <span className="flex items-center gap-1"><Circle size={10} /> Common App</span>
                              <span className="flex items-center gap-1"><Circle size={10} /> CSS Profile</span>
                              <span className="flex items-center gap-1"><Circle size={10} /> Transcripts</span>
                            </div>
                          </div>
                          <button 
                            onClick={() => toggleTrack(id)}
                            className="text-slate-400 hover:text-red-500"
                          >
                            <TrashButton />
                          </button>
                        </div>
                      ) : null;
                    })}
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-indigo-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="font-bold text-xl mb-2 italic">Parent's Advisor</h3>
                  <p className="text-indigo-200 text-sm leading-relaxed mb-6">
                    용인외대부고 국제반 학생들에게 가장 유리한 퀀트/금융 경로는 
                    Engineering 계열의 STEM 전공입니다. 졸업 후 OPT 3년이 보장되어 
                    미국 금융권 현지 취업에 매우 유리합니다.
                  </p>
                  <div className="bg-indigo-800/50 rounded-xl p-4 border border-indigo-700">
                    <p className="text-xs uppercase tracking-wider text-indigo-400 font-bold mb-2">Check Tip</p>
                    <p className="text-sm">FA를 신청할 경우 합격 확률에 영향을 줄 수 있는 Need-aware 제도를 꼭 확인하세요.</p>
                  </div>
                </div>
                <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-white/5 rounded-full" />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'dashboard' && (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-6 py-4 font-bold text-sm text-slate-600">대학교</th>
                    <th className="px-6 py-4 font-bold text-sm text-slate-600">연간 COA (Total)</th>
                    <th className="px-6 py-4 font-bold text-sm text-slate-600">FA (재정지원) 신청 시</th>
                    <th className="px-6 py-4 font-bold text-sm text-slate-600">성격</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {UNIVERSITIES.map(u => (
                    <tr key={u.id} className="hover:bg-indigo-50/30 transition-colors">
                      <td className="px-6 py-4">
                        <div className="font-bold">{u.name}</div>
                        <div className="text-xs text-slate-500">{u.location}</div>
                      </td>
                      <td className="px-6 py-4 font-mono font-medium text-indigo-600">
                        {u.coa}
                      </td>
                      <td className="px-6 py-4 text-sm">
                        <span className={`px-2 py-1 rounded-md ${u.faRequest.includes('불리') ? 'bg-orange-100 text-orange-700' : 'bg-green-100 text-green-700'}`}>
                          {u.faRequest}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-600 italic">
                        {u.traits}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedUniv && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedUniv(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" 
            />
            <motion.div 
              layoutId={selectedUniv.id}
              className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl relative z-10 overflow-hidden"
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
            >
              <div className="h-32 bg-indigo-600 flex items-end p-8">
                <div className="text-white">
                  <h2 className="text-3xl font-bold">{selectedUniv.name}</h2>
                  <p className="flex items-center gap-1 text-indigo-100 opacity-80"><MapPin size={16}/> {selectedUniv.location}</p>
                </div>
              </div>
              <div className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-8">
                  <div>
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">추천 전공</h4>
                    <p className="font-semibold text-lg">{selectedUniv.major}</p>
                    <div className="mt-2 inline-flex items-center gap-1 bg-green-100 text-green-700 px-2 py-0.5 rounded text-xs font-bold">
                      STEM 인증 (OPT 3년)
                    </div>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Estimated COA</h4>
                    <p className="font-semibold text-lg text-indigo-600">{selectedUniv.coa} <span className="text-sm font-normal text-slate-500">/ Year</span></p>
                  </div>
                </div>

                <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 grid grid-cols-3 gap-4">
                  <DetailCap icon={<Building2 size={18}/>} label="Type" value={selectedUniv.type} />
                  <DetailCap icon={<Users size={18}/>} label="Size" value={`${selectedUniv.undergradSize.toLocaleString()} 학부생`} />
                  <DetailCap icon={<Clock size={18}/>} label="Timezone" value={selectedUniv.timeZone} />
                </div>

                <div className="space-y-4">
                  <h4 className="font-bold border-b border-slate-200 pb-2">지원 및 취업 조건</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-white border border-slate-200 rounded-xl">
                      <p className="text-xs text-slate-400 mb-1">유학생 취업 및 STEM 강점</p>
                      <p className="font-medium text-sm">{selectedUniv.employmentStrength}</p>
                    </div>
                    <div className="p-4 bg-white border border-slate-200 rounded-xl">
                      <p className="text-xs text-slate-400 mb-1">FA 신청 시 유불리</p>
                      <p className="font-medium text-sm">{selectedUniv.faRequest}</p>
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => setSelectedUniv(null)}
                  className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-black transition-colors"
                >
                  Close Explorer
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function TimeDisplay({ label, time, status, color = 'slate' }: { label: string, time: string, status: string, color?: string }) {
  const isIndigo = color === 'indigo';
  return (
    <div className={`flex flex-col min-w-[120px] transition-all`}>
      <span className={`text-[10px] font-bold uppercase tracking-wider ${isIndigo ? 'text-indigo-600' : 'text-slate-400'}`}>
        {label}
      </span>
      <div className="flex items-baseline gap-1">
        <span className={`text-sm font-mono font-bold ${isIndigo ? 'text-indigo-900' : 'text-slate-700'}`}>{time}</span>
        <span className={`text-[10px] font-medium px-1 rounded ${status === 'Today' ? 'bg-green-50 text-green-600' : 'bg-slate-100 text-slate-500'}`}>
          {status}
        </span>
      </div>
    </div>
  );
}

function TabButton({ active, label, icon, onClick }: { active: boolean, label: string, icon: React.ReactNode, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${
        active 
          ? 'bg-white text-indigo-600 shadow-sm' 
          : 'text-slate-500 hover:text-slate-700'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function UniversityCard({ univ, isTracking, onToggleTrack, onClick }: { univ: University, isTracking: boolean, onToggleTrack: () => void, onClick: () => void }) {
  return (
    <motion.div 
      layoutId={univ.id}
      className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all cursor-pointer group relative flex flex-col"
      onClick={onClick}
    >
      <button 
        onClick={(e) => {
          e.stopPropagation();
          onToggleTrack();
        }}
        className={`absolute top-4 right-4 p-2 rounded-full transition-colors ${
          isTracking ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-400'
        }`}
      >
        <Plus size={18} className={`transition-transform ${isTracking ? 'rotate-45' : 'rotate-0'}`} />
      </button>

      <div className="mb-4">
        <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-500 mb-1 block">
          {univ.type} · {univ.location}
        </span>
        <h3 className="text-xl font-bold group-hover:text-indigo-600 transition-colors leading-tight">{univ.name}</h3>
      </div>

      <div className="flex-grow space-y-3 mb-6">
        <div className="flex items-center gap-2 text-sm">
          <GraduationCap size={16} className="text-slate-400" />
          <span className="font-medium text-slate-700 line-clamp-1">{univ.major}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-slate-500">
          <DollarSign size={16} className="text-slate-400" />
          <span>{univ.coa} / Year</span>
        </div>
      </div>

      <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
        <span className="text-xs font-bold text-slate-400">FA: {univ.faRequest}</span>
        <ChevronRight size={16} className="text-slate-300 group-hover:translate-x-1 transition-transform" />
      </div>
    </motion.div>
  );
}

function TrackerItem({ title, desc, date, status }: { title: string, desc: string, date: string, status: 'urgent' | 'ongoing' | 'upcoming' }) {
  const colors = {
    urgent: 'bg-red-50 text-red-600 border-red-100',
    ongoing: 'bg-indigo-50 text-indigo-600 border-indigo-100',
    upcoming: 'bg-slate-50 text-slate-600 border-slate-100'
  };

  return (
    <div className={`p-5 rounded-2xl border ${colors[status]} flex items-start gap-4`}>
      <div className="mt-1">
        {status === 'urgent' ? <AlertCircle size={20} /> : <Circle size={20} />}
      </div>
      <div className="flex-grow">
        <div className="flex justify-between items-start">
          <h4 className="font-bold">{title}</h4>
          <span className="text-xs font-bold font-mono px-2 py-1 bg-white/50 rounded-lg">{date}</span>
        </div>
        <p className="text-sm opacity-80 mt-1">{desc}</p>
      </div>
    </div>
  );
}

function DetailCap({ icon, label, value }: { icon: React.ReactNode, label: string, value: string }) {
  return (
    <div className="flex flex-col items-center text-center p-2">
      <div className="text-slate-400 mb-1">{icon}</div>
      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{label}</span>
      <span className="text-xs font-bold text-slate-700">{value}</span>
    </div>
  );
}

function TrashButton() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
  );
}
